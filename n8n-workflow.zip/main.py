from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import os

app = FastAPI(title='n8n2py Converted Workflow')

import json
import os
import requests

def run_workflow(input_data: dict | list | None = None):
    # Converted from n8n workflow: My workflow 19 (35 nodes)
    output = None

            # Airtable: Update record6
            # TODO: Set AIRTABLE_API_KEY env var.
            at_key = os.getenv('AIRTABLE_API_KEY')
            headers={'Authorization': f'Bearer {at_key}', 'Content-Type':'application/json'} if at_key else {'Content-Type':'application/json'}
            base_url=f"https://api.airtable.com/v0//[object Object]"
            update_record6_result={'success': False}

            # Supports single or batch update
            typecast = False
            recs=[]
            if isinstance(recs, list) and recs:
                payload={'records': [{'id': r.get('id'), 'fields': r.get('fields', {})} for r in recs], 'typecast': typecast}
                resp=requests.patch(base_url, headers=headers, json=payload, timeout=30)
            else:
                rec_id = ""
                payload={}
                resp=requests.patch(f"{base_url}/{rec_id}", headers=headers, json={'fields': payload, 'typecast': typecast}, timeout=30)
            update_record6_result={'success': resp.ok, 'data': resp.json() if resp.text else {}}


            # Airtable: Search records3
            # TODO: Set AIRTABLE_API_KEY env var.
            at_key = os.getenv('AIRTABLE_API_KEY')
            headers={'Authorization': f'Bearer {at_key}', 'Content-Type':'application/json'} if at_key else {'Content-Type':'application/json'}
            base_url=f"https://api.airtable.com/v0//[object Object]"
            search_records3_result={'success': False}

            # TODO: Unsupported Airtable operation: search


            # Airtable Trigger (hardened): UploadSaree1
            async def _verify_signature_uploadsaree1(raw_body: bytes, headers: dict) -> bool:
                secret = os.getenv('AIRTABLE_WEBHOOK_SECRET')
                if not secret:
                    return True
                recv_sig = headers.get('X-Airtable-Hmac-Sha256') or headers.get('X-Airtable-Hmac-Sha256'.lower())
                if not recv_sig:
                    return False
                mac = hmac.new(secret.encode('utf-8'), raw_body, hashlib.sha256).hexdigest()
                return hmac.compare_digest(recv_sig, mac)

            @app.get("/webhooks/airtable")
            async def uploadsaree1_ping(challenge: str | None = None):
                if challenge:
                    return Response(content=challenge, media_type='text/plain')
                return {'success': True, 'message': 'airtable webhook ready'}

            @app.post("/webhooks/airtable")
            async def airtable_webhook(request: Request):
                raw = await request.body()
                if not await _verify_signature_uploadsaree1(raw, request.headers):
                    return Response(status_code=status.HTTP_401_UNAUTHORIZED)
                try:
                    payload = await request.json()
                except Exception:
                    payload = {}
                uploadsaree1_event = {'success': True, 'source': 'airtable', 'data': payload}
                return uploadsaree1_event


            # HTTP Request: HTTP Request17
            # Request Configuration
            http_request17_config = {
                'method': 'GET',
                'url': f"""={$json["Saree"][0]["url"]}""",
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request17_response = requests.request(
                    method=http_request17_config['method'],
                    url=http_request17_config['url'],
                    params=http_request17_config.get('params'),
                    headers=http_request17_config.get('headers'),
                    json=http_request17_config.get('json'),
                    data=http_request17_config.get('data'),
                    files=http_request17_config.get('files'),
                    auth=http_request17_config.get('auth'),
                    timeout=http_request17_config.get('timeout'),
                    allow_redirects=http_request17_config.get('allow_redirects'),
                    verify=http_request17_config.get('verify'),
                )

                # Process response
                http_request17_result = {
                    'status_code': http_request17_response.status_code,
                    'headers': dict(http_request17_response.headers),
                    'success': 200 <= http_request17_response.status_code < 300,
                    'data': http_request17_response.json() if http_request17_response.headers.get('content-type', '').startswith('application/json') else http_request17_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request17_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Limit: Limit1
            try:
                # Ensure items is a flat list
                flat: List[Any] = []
                for it in items:
                    if isinstance(it, list):
                        flat.extend(it)
                    else:
                        flat.append(it)

                limited = flat[:100]
                limit1_result = {'success': True, 'data': limited, 'count': len(limited)}
            except Exception as e:
                limit1_result = {'success': False, 'error': str(e)}


            # Code: Code3
            def custom_code_code3(items: List[Dict[str, Any]], input_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
                try:
                    return items
                    # Ensure a list of dicts is returned
                    return items if items is not None else []
                except Exception as e:
                    # Fallback on error
                    print(f"Code node error: {type(e).__name__}: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    return items

            # Execute custom code with provided items
            try:
                code3_output = custom_code_code3(items=items, input_data=items)
            except Exception as e:
                print(f"Code node execution error: {type(e).__name__}: {str(e)}")
                import traceback
                traceback.print_exc()
                code3_output = items

            code3_result = {'success': True, 'data': code3_output}

                context.setNodeOutput(node.id, code3_result)


            # Extract From File: Extract from File3
            try:
                fp = ""
                if not fp:
                    raise ValueError('path is required')
                if not os.path.exists(fp):
                    raise FileNotFoundError('file not found')
                if false:
                    with open(fp, 'rb') as f:
                        data = f.read()
                    extract_from_file3_result = { 'success': True, 'binary': True, 'size': len(data) }
                else:
                    # naive text read
                    with open(fp, 'r', encoding='utf-8', errors='replace') as f:
                        text = f.read()
                    extract_from_file3_result = { 'success': True, 'binary': False, 'text': text, 'length': len(text) }
            except Exception as e:
                extract_from_file3_result = { 'success': False, 'error': str(e), 'error_type': type(e).__name__ }


            # HTTP Request: HTTP Request18
            # Request Configuration
            http_request18_config = {
                'method': 'GET',
                'url': f"""=https://api.freepik.com/v1/ai/image-upscaler-precision-v2/{ $json.data.task_id }""",
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request18_response = requests.request(
                    method=http_request18_config['method'],
                    url=http_request18_config['url'],
                    params=http_request18_config.get('params'),
                    headers=http_request18_config.get('headers'),
                    json=http_request18_config.get('json'),
                    data=http_request18_config.get('data'),
                    files=http_request18_config.get('files'),
                    auth=http_request18_config.get('auth'),
                    timeout=http_request18_config.get('timeout'),
                    allow_redirects=http_request18_config.get('allow_redirects'),
                    verify=http_request18_config.get('verify'),
                )

                # Process response
                http_request18_result = {
                    'status_code': http_request18_response.status_code,
                    'headers': dict(http_request18_response.headers),
                    'success': 200 <= http_request18_response.status_code < 300,
                    'data': http_request18_response.json() if http_request18_response.headers.get('content-type', '').startswith('application/json') else http_request18_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request18_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # HTTP Request: HTTP Request19
            # Request Configuration
            http_request19_config = {
                'method': 'GET',
                'url': os.getenv('HTTP_BASE_URL', "'https://api.freepik.com/v1/ai/image-upscaler-precision-v2'"),
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request19_response = requests.request(
                    method=http_request19_config['method'],
                    url=http_request19_config['url'],
                    params=http_request19_config.get('params'),
                    headers=http_request19_config.get('headers'),
                    json=http_request19_config.get('json'),
                    data=http_request19_config.get('data'),
                    files=http_request19_config.get('files'),
                    auth=http_request19_config.get('auth'),
                    timeout=http_request19_config.get('timeout'),
                    allow_redirects=http_request19_config.get('allow_redirects'),
                    verify=http_request19_config.get('verify'),
                )

                # Process response
                http_request19_result = {
                    'status_code': http_request19_response.status_code,
                    'headers': dict(http_request19_response.headers),
                    'success': 200 <= http_request19_response.status_code < 300,
                    'data': http_request19_response.json() if http_request19_response.headers.get('content-type', '').startswith('application/json') else http_request19_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request19_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Wait: Wait13
            # Waiting for 1 seconds
            time.sleep(1)
            # Continuing workflow after wait


            # Switch: Switch3
            # Switch node evaluates 3 rules
            switch_output = None
            input_data = input_data[0]

            # Rule 1: no operation
            if not switch_output and (False  # Unsupported condition operation):
                switch_output = "Rule 1 matched"
                # Add your rule-specific logic here

            # Rule 2: no operation
            if not switch_output and (False  # Unsupported condition operation):
                switch_output = "Rule 2 matched"
                # Add your rule-specific logic here

            # Rule 3: no operation
            if not switch_output and (False  # Unsupported condition operation):
                switch_output = "Rule 3 matched"
                # Add your rule-specific logic here

            if switch_output is None:
                switch_output = "No rules matched"
                # Add your default case logic here


            # Airtable: Search records1
            # TODO: Set AIRTABLE_API_KEY env var.
            at_key = os.getenv('AIRTABLE_API_KEY')
            headers={'Authorization': f'Bearer {at_key}', 'Content-Type':'application/json'} if at_key else {'Content-Type':'application/json'}
            base_url=f"https://api.airtable.com/v0//[object Object]"
            search_records1_result={'success': False}

            # TODO: Unsupported Airtable operation: search


            # Wait: Wait9
            # Waiting for 1 seconds
            time.sleep(1)
            # Continuing workflow after wait


            # HTTP Request: Get  Video4
            # Request Configuration
            get_video4_config = {
                'method': 'GET',
                'url': os.getenv('HTTP_BASE_URL', "'https://api.kie.ai/api/v1/jobs/recordInfo'"),
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                get_video4_response = requests.request(
                    method=get_video4_config['method'],
                    url=get_video4_config['url'],
                    params=get_video4_config.get('params'),
                    headers=get_video4_config.get('headers'),
                    json=get_video4_config.get('json'),
                    data=get_video4_config.get('data'),
                    files=get_video4_config.get('files'),
                    auth=get_video4_config.get('auth'),
                    timeout=get_video4_config.get('timeout'),
                    allow_redirects=get_video4_config.get('allow_redirects'),
                    verify=get_video4_config.get('verify'),
                )

                # Process response
                get_video4_result = {
                    'status_code': get_video4_response.status_code,
                    'headers': dict(get_video4_response.headers),
                    'success': 200 <= get_video4_response.status_code < 300,
                    'data': get_video4_response.json() if get_video4_response.headers.get('content-type', '').startswith('application/json') else get_video4_response.text
                }

            except requests.exceptions.RequestException as e:
                get_video4_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # HTTP Request: Download3
            # Request Configuration
            download3_config = {
                'method': 'GET',
                'url': f"""={ JSON.parse($json.data.resultJson).resultUrls[0] }""",
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                download3_response = requests.request(
                    method=download3_config['method'],
                    url=download3_config['url'],
                    params=download3_config.get('params'),
                    headers=download3_config.get('headers'),
                    json=download3_config.get('json'),
                    data=download3_config.get('data'),
                    files=download3_config.get('files'),
                    auth=download3_config.get('auth'),
                    timeout=download3_config.get('timeout'),
                    allow_redirects=download3_config.get('allow_redirects'),
                    verify=download3_config.get('verify'),
                )

                # Process response
                download3_result = {
                    'status_code': download3_response.status_code,
                    'headers': dict(download3_response.headers),
                    'success': 200 <= download3_response.status_code < 300,
                    'data': download3_response.json() if download3_response.headers.get('content-type', '').startswith('application/json') else download3_response.text
                }

            except requests.exceptions.RequestException as e:
                download3_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Airtable: Update record
            # TODO: Set AIRTABLE_API_KEY env var.
            at_key = os.getenv('AIRTABLE_API_KEY')
            headers={'Authorization': f'Bearer {at_key}', 'Content-Type':'application/json'} if at_key else {'Content-Type':'application/json'}
            base_url=f"https://api.airtable.com/v0//[object Object]"
            update_record_result={'success': False}

            # Supports single or batch update
            typecast = False
            recs=[]
            if isinstance(recs, list) and recs:
                payload={'records': [{'id': r.get('id'), 'fields': r.get('fields', {})} for r in recs], 'typecast': typecast}
                resp=requests.patch(base_url, headers=headers, json=payload, timeout=30)
            else:
                rec_id = ""
                payload={}
                resp=requests.patch(f"{base_url}/{rec_id}", headers=headers, json={'fields': payload, 'typecast': typecast}, timeout=30)
            update_record_result={'success': resp.ok, 'data': resp.json() if resp.text else {}}


            # Wait: Wait7
            # Waiting for 1 seconds
            time.sleep(1)
            # Continuing workflow after wait


            # HTTP Request: Video Gen9
            # Request Configuration
            video_gen9_config = {
                'method': 'GET',
                'url': os.getenv('HTTP_BASE_URL', "'https://api.kie.ai/api/v1/jobs/createTask'"),
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                video_gen9_response = requests.request(
                    method=video_gen9_config['method'],
                    url=video_gen9_config['url'],
                    params=video_gen9_config.get('params'),
                    headers=video_gen9_config.get('headers'),
                    json=video_gen9_config.get('json'),
                    data=video_gen9_config.get('data'),
                    files=video_gen9_config.get('files'),
                    auth=video_gen9_config.get('auth'),
                    timeout=video_gen9_config.get('timeout'),
                    allow_redirects=video_gen9_config.get('allow_redirects'),
                    verify=video_gen9_config.get('verify'),
                )

                # Process response
                video_gen9_result = {
                    'status_code': video_gen9_response.status_code,
                    'headers': dict(video_gen9_response.headers),
                    'success': 200 <= video_gen9_response.status_code < 300,
                    'data': video_gen9_response.json() if video_gen9_response.headers.get('content-type', '').startswith('application/json') else video_gen9_response.text
                }

            except requests.exceptions.RequestException as e:
                video_gen9_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Airtable Trigger (hardened): Airtable Trigger1
            async def _verify_signature_airtable_trigger1(raw_body: bytes, headers: dict) -> bool:
                secret = os.getenv('AIRTABLE_WEBHOOK_SECRET')
                if not secret:
                    return True
                recv_sig = headers.get('X-Airtable-Hmac-Sha256') or headers.get('X-Airtable-Hmac-Sha256'.lower())
                if not recv_sig:
                    return False
                mac = hmac.new(secret.encode('utf-8'), raw_body, hashlib.sha256).hexdigest()
                return hmac.compare_digest(recv_sig, mac)

            @app.get("/webhooks/airtable")
            async def airtable_trigger1_ping(challenge: str | None = None):
                if challenge:
                    return Response(content=challenge, media_type='text/plain')
                return {'success': True, 'message': 'airtable webhook ready'}

            @app.post("/webhooks/airtable")
            async def airtable_webhook(request: Request):
                raw = await request.body()
                if not await _verify_signature_airtable_trigger1(raw, request.headers):
                    return Response(status_code=status.HTTP_401_UNAUTHORIZED)
                try:
                    payload = await request.json()
                except Exception:
                    payload = {}
                airtable_trigger1_event = {'success': True, 'source': 'airtable', 'data': payload}
                return airtable_trigger1_event


            # Airtable: Search records4
            # TODO: Set AIRTABLE_API_KEY env var.
            at_key = os.getenv('AIRTABLE_API_KEY')
            headers={'Authorization': f'Bearer {at_key}', 'Content-Type':'application/json'} if at_key else {'Content-Type':'application/json'}
            base_url=f"https://api.airtable.com/v0//[object Object]"
            search_records4_result={'success': False}

            # TODO: Unsupported Airtable operation: search


            # Airtable Trigger (hardened): UploadSaree
            async def _verify_signature_uploadsaree(raw_body: bytes, headers: dict) -> bool:
                secret = os.getenv('AIRTABLE_WEBHOOK_SECRET')
                if not secret:
                    return True
                recv_sig = headers.get('X-Airtable-Hmac-Sha256') or headers.get('X-Airtable-Hmac-Sha256'.lower())
                if not recv_sig:
                    return False
                mac = hmac.new(secret.encode('utf-8'), raw_body, hashlib.sha256).hexdigest()
                return hmac.compare_digest(recv_sig, mac)

            @app.get("/webhooks/airtable")
            async def uploadsaree_ping(challenge: str | None = None):
                if challenge:
                    return Response(content=challenge, media_type='text/plain')
                return {'success': True, 'message': 'airtable webhook ready'}

            @app.post("/webhooks/airtable")
            async def airtable_webhook(request: Request):
                raw = await request.body()
                if not await _verify_signature_uploadsaree(raw, request.headers):
                    return Response(status_code=status.HTTP_401_UNAUTHORIZED)
                try:
                    payload = await request.json()
                except Exception:
                    payload = {}
                uploadsaree_event = {'success': True, 'source': 'airtable', 'data': payload}
                return uploadsaree_event


            # HTTP Request: HTTP Request8
            # Request Configuration
            http_request8_config = {
                'method': 'GET',
                'url': os.getenv('HTTP_BASE_URL', "'https://api.imgbb.com/1/upload?key=fa4504c3c279614ee255d5ad75aa76f6'"),
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request8_response = requests.request(
                    method=http_request8_config['method'],
                    url=http_request8_config['url'],
                    params=http_request8_config.get('params'),
                    headers=http_request8_config.get('headers'),
                    json=http_request8_config.get('json'),
                    data=http_request8_config.get('data'),
                    files=http_request8_config.get('files'),
                    auth=http_request8_config.get('auth'),
                    timeout=http_request8_config.get('timeout'),
                    allow_redirects=http_request8_config.get('allow_redirects'),
                    verify=http_request8_config.get('verify'),
                )

                # Process response
                http_request8_result = {
                    'status_code': http_request8_response.status_code,
                    'headers': dict(http_request8_response.headers),
                    'success': 200 <= http_request8_response.status_code < 300,
                    'data': http_request8_response.json() if http_request8_response.headers.get('content-type', '').startswith('application/json') else http_request8_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request8_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Convert To File: Convert to File6
            # TODO: Configure conversion settings if needed

            # Item operations

            # Unsupported item operation: toBinary
            convert_to_file6_result = {
                'success': False,
                'error': f"Unsupported item operation: toBinary"
            }

            except Exception as e:
                convert_to_file6_result = {
                    'success': False,
                    'error': f"An unexpected error occurred: {str(e)}",
                    'error_type': type(e).__name__
                }


            # Set Variables: Edit Fields7
            # No variables to set


            # Airtable: Update record10
            # TODO: Set AIRTABLE_API_KEY env var.
            at_key = os.getenv('AIRTABLE_API_KEY')
            headers={'Authorization': f'Bearer {at_key}', 'Content-Type':'application/json'} if at_key else {'Content-Type':'application/json'}
            base_url=f"https://api.airtable.com/v0//[object Object]"
            update_record10_result={'success': False}

            # Supports single or batch update
            typecast = False
            recs=[]
            if isinstance(recs, list) and recs:
                payload={'records': [{'id': r.get('id'), 'fields': r.get('fields', {})} for r in recs], 'typecast': typecast}
                resp=requests.patch(base_url, headers=headers, json=payload, timeout=30)
            else:
                rec_id = ""
                payload={}
                resp=requests.patch(f"{base_url}/{rec_id}", headers=headers, json={'fields': payload, 'typecast': typecast}, timeout=30)
            update_record10_result={'success': resp.ok, 'data': resp.json() if resp.text else {}}


            # Wait: Wait
            # Waiting for 1 seconds
            time.sleep(1)
            # Continuing workflow after wait


            # Code: Code6
            def custom_code_code6(items: List[Dict[str, Any]], input_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
                try:
                    return items
                    # Ensure a list of dicts is returned
                    return items if items is not None else []
                except Exception as e:
                    # Fallback on error
                    print(f"Code node error: {type(e).__name__}: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    return items

            # Execute custom code with provided items
            try:
                code6_output = custom_code_code6(items=items, input_data=items)
            except Exception as e:
                print(f"Code node execution error: {type(e).__name__}: {str(e)}")
                import traceback
                traceback.print_exc()
                code6_output = items

            code6_result = {'success': True, 'data': code6_output}

                context.setNodeOutput(node.id, code6_result)


            # Extract From File: Extract from File6
            try:
                fp = ""
                if not fp:
                    raise ValueError('path is required')
                if not os.path.exists(fp):
                    raise FileNotFoundError('file not found')
                if false:
                    with open(fp, 'rb') as f:
                        data = f.read()
                    extract_from_file6_result = { 'success': True, 'binary': True, 'size': len(data) }
                else:
                    # naive text read
                    with open(fp, 'r', encoding='utf-8', errors='replace') as f:
                        text = f.read()
                    extract_from_file6_result = { 'success': True, 'binary': False, 'text': text, 'length': len(text) }
            except Exception as e:
                extract_from_file6_result = { 'success': False, 'error': str(e), 'error_type': type(e).__name__ }


            # HTTP Request: HTTP Request29
            # Request Configuration
            http_request29_config = {
                'method': 'GET',
                'url': f"""=https://api.freepik.com/v1/ai/image-upscaler-precision-v2/{ $json.data.task_id }""",
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request29_response = requests.request(
                    method=http_request29_config['method'],
                    url=http_request29_config['url'],
                    params=http_request29_config.get('params'),
                    headers=http_request29_config.get('headers'),
                    json=http_request29_config.get('json'),
                    data=http_request29_config.get('data'),
                    files=http_request29_config.get('files'),
                    auth=http_request29_config.get('auth'),
                    timeout=http_request29_config.get('timeout'),
                    allow_redirects=http_request29_config.get('allow_redirects'),
                    verify=http_request29_config.get('verify'),
                )

                # Process response
                http_request29_result = {
                    'status_code': http_request29_response.status_code,
                    'headers': dict(http_request29_response.headers),
                    'success': 200 <= http_request29_response.status_code < 300,
                    'data': http_request29_response.json() if http_request29_response.headers.get('content-type', '').startswith('application/json') else http_request29_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request29_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # HTTP Request: HTTP Request30
            # Request Configuration
            http_request30_config = {
                'method': 'GET',
                'url': os.getenv('HTTP_BASE_URL', "'https://api.freepik.com/v1/ai/image-upscaler-precision-v2'"),
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request30_response = requests.request(
                    method=http_request30_config['method'],
                    url=http_request30_config['url'],
                    params=http_request30_config.get('params'),
                    headers=http_request30_config.get('headers'),
                    json=http_request30_config.get('json'),
                    data=http_request30_config.get('data'),
                    files=http_request30_config.get('files'),
                    auth=http_request30_config.get('auth'),
                    timeout=http_request30_config.get('timeout'),
                    allow_redirects=http_request30_config.get('allow_redirects'),
                    verify=http_request30_config.get('verify'),
                )

                # Process response
                http_request30_result = {
                    'status_code': http_request30_response.status_code,
                    'headers': dict(http_request30_response.headers),
                    'success': 200 <= http_request30_response.status_code < 300,
                    'data': http_request30_response.json() if http_request30_response.headers.get('content-type', '').startswith('application/json') else http_request30_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request30_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Wait: Wait17
            # Waiting for 1 seconds
            time.sleep(1)
            # Continuing workflow after wait


            # Switch: Switch
            # Switch node evaluates 3 rules
            switch_output = None
            input_data = input_data[0]

            # Rule 1: no operation
            if not switch_output and (False  # Unsupported condition operation):
                switch_output = "Rule 1 matched"
                # Add your rule-specific logic here

            # Rule 2: no operation
            if not switch_output and (False  # Unsupported condition operation):
                switch_output = "Rule 2 matched"
                # Add your rule-specific logic here

            # Rule 3: no operation
            if not switch_output and (False  # Unsupported condition operation):
                switch_output = "Rule 3 matched"
                # Add your rule-specific logic here

            if switch_output is None:
                switch_output = "No rules matched"
                # Add your default case logic here


            # HTTP Request: HTTP Request31
            # Request Configuration
            http_request31_config = {
                'method': 'GET',
                'url': f"""={ $json.data.generated[0] }""",
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                http_request31_response = requests.request(
                    method=http_request31_config['method'],
                    url=http_request31_config['url'],
                    params=http_request31_config.get('params'),
                    headers=http_request31_config.get('headers'),
                    json=http_request31_config.get('json'),
                    data=http_request31_config.get('data'),
                    files=http_request31_config.get('files'),
                    auth=http_request31_config.get('auth'),
                    timeout=http_request31_config.get('timeout'),
                    allow_redirects=http_request31_config.get('allow_redirects'),
                    verify=http_request31_config.get('verify'),
                )

                # Process response
                http_request31_result = {
                    'status_code': http_request31_response.status_code,
                    'headers': dict(http_request31_response.headers),
                    'success': 200 <= http_request31_response.status_code < 300,
                    'data': http_request31_response.json() if http_request31_response.headers.get('content-type', '').startswith('application/json') else http_request31_response.text
                }

            except requests.exceptions.RequestException as e:
                http_request31_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # HTTP Request: FRONT FULL VIEW7
            # Request Configuration
            front_full_view7_config = {
                'method': 'GET',
                'url': os.getenv('HTTP_BASE_URL', "'https://openrouter.ai/api/v1/chat/completions'"),
                'headers': {
                    'User-Agent': 'n8n-http-request/1.0',
                },
                'timeout': 30,  # Convert to seconds
                'allow_redirects': true,
                'verify': true,
            }

            # Make the HTTP request
            try:
                front_full_view7_response = requests.request(
                    method=front_full_view7_config['method'],
                    url=front_full_view7_config['url'],
                    params=front_full_view7_config.get('params'),
                    headers=front_full_view7_config.get('headers'),
                    json=front_full_view7_config.get('json'),
                    data=front_full_view7_config.get('data'),
                    files=front_full_view7_config.get('files'),
                    auth=front_full_view7_config.get('auth'),
                    timeout=front_full_view7_config.get('timeout'),
                    allow_redirects=front_full_view7_config.get('allow_redirects'),
                    verify=front_full_view7_config.get('verify'),
                )

                # Process response
                front_full_view7_result = {
                    'status_code': front_full_view7_response.status_code,
                    'headers': dict(front_full_view7_response.headers),
                    'success': 200 <= front_full_view7_response.status_code < 300,
                    'data': front_full_view7_response.json() if front_full_view7_response.headers.get('content-type', '').startswith('application/json') else front_full_view7_response.text
                }

            except requests.exceptions.RequestException as e:
                front_full_view7_result = {
                    'status_code': getattr(e.response, 'status_code', 500) if hasattr(e, 'response') else 500,
                    'error': str(e),
                    'success': False
                }



            # Limit: Limit5
            try:
                # Ensure items is a flat list
                flat: List[Any] = []
                for it in items:
                    if isinstance(it, list):
                        flat.extend(it)
                    else:
                        flat.append(it)

                limited = flat[:100]
                limit5_result = {'success': True, 'data': limited, 'count': len(limited)}
            except Exception as e:
                limit5_result = {'success': False, 'error': str(e)}

    return output

if __name__ == '__main__':
    print('Running workflow...')
    result = run_workflow({})
    print('Done. Result:', result)


@app.get('/')
async def root():
    return {'ok': True}

@app.post('/run')
async def run(request: Request):
    try:
        data = await request.json()
    except Exception:
        data = {}
    return JSONResponse(run_workflow(data))
